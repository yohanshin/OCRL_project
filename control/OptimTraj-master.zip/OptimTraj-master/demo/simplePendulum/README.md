# README  --  Simple Pendulum

This example show how to compute the optimal swing-up trajectory for a simple pendulum.