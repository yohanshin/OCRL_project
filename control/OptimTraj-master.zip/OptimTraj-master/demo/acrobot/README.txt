README.txt  --  Acrobot

This directory contains Matlab code for generating an optimal swing-up trajectory for the Acrobot: a double pendulum robot with a motor between the two links. It is underactuated: two degrees of freedom and one motor.

Run the example using MAIN.m

Derive the equations of motion using Derive_acrobot.m

