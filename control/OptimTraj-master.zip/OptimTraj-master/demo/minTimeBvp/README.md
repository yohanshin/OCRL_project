# README  --  Minimum-Time Boundary Value Problem

This example show how to compute the a minimum-time solution for boundary value problem with kinematic limits: position, velocity, acceleration, and jerk.
